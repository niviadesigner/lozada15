# 15 Años Lozada & Partners — versión autónoma (Firebase)

Esta es la misma pieza interactiva (carrusel 2011–2026, música, confeti,
descarga/compartir tarjetas), pero con los **recuerdos compartidos** corriendo
sobre tu propio proyecto de Firebase en vez de la base de datos de Claude.
Queda 100% independiente — se sube a cualquier hosting y funciona para
cualquiera, sin necesidad de cuenta en claude.ai.

## Qué venía ya resuelto
- Todo el carrusel, fotos, música y efectos: listos, no requieren configuración.
- El formulario de "Deja un mensaje o recuerdo para Lozada" ya está conectado
  en el código a Firestore (base de datos) y Firebase Storage (fotos) —
  **solo falta pegar las credenciales de tu proyecto** (siguiente sección) y
  publicar las reglas de seguridad incluidas.
- Si no se configura Firebase, el botón cae automáticamente a compartir el
  recuerdo por WhatsApp desde el teléfono de cada persona (no se rompe nada,
  simplemente no queda guardado para que todos lo vean).

## Paso a paso para dejarlo 100% funcional

### 1. Crear el proyecto de Firebase (gratis)
1. Entra a https://console.firebase.google.com
2. "Agregar proyecto" → nómbralo como quieras (ej. `lozada-15-anos`) → sigue el asistente (puedes desactivar Google Analytics, no se usa aquí).
3. Cuando termine, quedas dentro del panel del proyecto.

### 2. Activar Firestore (la base de datos)
1. Menú lateral → **Build → Firestore Database** → "Crear base de datos".
2. Modo: **producción** (vamos a pegar nuestras propias reglas, no las de prueba).
3. Elige la región más cercana (ej. `southamerica-east1` o `us-central1`).

### 3. Activar Storage (para las fotos adjuntas)
1. Menú lateral → **Build → Storage** → "Comenzar".
2. Acepta la ubicación por defecto (la misma región de Firestore, idealmente).

### 4. Registrar la app web y copiar las credenciales
1. Ícono de engranaje (arriba izquierda) → **Project settings**.
2. Baja hasta "Your apps" → clic en el ícono `</>` (Web).
3. Dale un apodo (ej. "web") → "Registrar app" → **NO** actives Firebase Hosting ahí.
4. Te muestra un bloque `firebaseConfig = {...}` — cópialo completo.

### 5. Pegar las credenciales en el HTML
Abre `index.html`, busca este bloque (cerca de la etiqueta `<audio id="bgMusic">`,
antes del script principal) y reemplaza los valores de ejemplo por los tuyos:

```js
var firebaseConfig = {
  apiKey: "PEGA_AQUI_TU_API_KEY",
  authDomain: "TU-PROYECTO.firebaseapp.com",
  projectId: "TU-PROYECTO",
  storageBucket: "TU-PROYECTO.appspot.com",
  messagingSenderId: "000000000000",
  appId: "1:000000000000:web:xxxxxxxxxxxxxxxxxx"
};
```

### 6. Publicar las reglas de seguridad (importante — no lo saltes)
Sin esto, cualquiera podría escribir/leer lo que quiera, o Firebase rechazará
todo por defecto.

**Firestore:** Firestore Database → pestaña "Reglas" → pega el contenido de
`firestore.rules` (incluido en este zip) → "Publicar".

**Storage:** Storage → pestaña "Reglas" → pega el contenido de
`storage.rules` (incluido) → "Publicar".

Estas reglas dejan: cualquiera puede **leer** los recuerdos y fotos (para que
las burbujas se vean), pero solo se pueden **crear** recuerdos nuevos con
nombre y texto válidos (nunca editar ni borrar los de otros), y solo subir
imágenes de hasta 8 MB.

### 7. Subir el sitio a tu hosting
`index.html` es un archivo único y autocontenido — se sube tal cual a
cualquier hosting (Hostinger, cPanel, Netlify, GitHub Pages, lo que uses).
No necesita servidor con Node, PHP, ni build — es HTML plano.

### 8. Probar
Abre el sitio ya publicado, dale a "Deja un mensaje o recuerdo para Lozada",
publica uno de prueba, y confirma que aparece la burbuja flotando. Si no
aparece, abre la consola del navegador (F12) y revisa si hay un error de
Firebase — casi siempre es: credenciales mal pegadas, o reglas no publicadas.

## Costos
Para este uso (un formulario interno, cientos de recuerdos, no millones),
el plan gratuito **Spark** de Firebase alcanza de sobra. No hace falta
tarjeta de crédito para el plan Spark.

## Si Code va a terminar esto
Lo único pendiente es:
1. Crear el proyecto de Firebase (paso 1-4) — requiere una cuenta Google del
   cliente, Code no puede crearlo por su cuenta.
2. Pegar el `firebaseConfig` real en `index.html` (paso 5).
3. Publicar `firestore.rules` y `storage.rules` en la consola (paso 6).
4. Subir `index.html` al hosting final (paso 7).
Todo el código de la app (carrusel, lógica de Firestore/Storage, UI) ya está
escrito y no debería requerir cambios — solo configuración.
